function enviarFormulario(){
    console.log ("enviando formulario")
    return false;
}





const btn_enviar = document.getElementById ('btnEnviar');

const validación = (e) => {
    e.preventDefault();
    const nombre = document.getElementById("nombre");
    const carreraQueEstudias = document.getElementById('carrera.que.estudias');
    if (nombre.value === "") {
      alert("Por favor escribe tu nombre.");
      nombre.focus();
      return false;
    }
    if (carrera.que.estudias.value === "") {
      alert("Ingrese su carrera");
      email.focus();
      return false;
    }
    
    return true;
  }
  
  submitBtn.addEventListener('click', validate);